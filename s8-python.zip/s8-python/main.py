import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

st.set_page_config(
    page_title="Análisis Interactivo de Datos CSV",
    layout="wide", #centered
    initial_sidebar_state="expanded",
)

st.title("Análisis Interactivo de Datos CSV")
st.markdown("""
Esta aplicación te permite cargar un archivo CSV, explorar los datos y visualizar diferentes gráficos interactivos. 
Utiliza el menú lateral para cargar datos y seleccionar opciones de análisis.
""")

# Función para cargar datos
def cargar_datos():
    st.sidebar.header("Carga de Datos")
    archivo = st.sidebar.file_uploader("Sube un archivo CSV", type=["csv"])
    if archivo is not None:
        datos = pd.read_csv(archivo)
        st.session_state['datos'] = datos  # Guardar datos en session_state
        st.write("### Vista previa de los datos", datos.head())
        return datos
    return None

# Función para explorar datos
def explorar_datos():
    st.sidebar.header("Exploración de Datos")
    datos = st.session_state['datos']  # Recuperar datos de session_state
    if st.sidebar.checkbox("Mostrar resumen de datos"):
        st.write("### Resumen estadístico de los datos")
        st.write(datos.describe())

    columnas = datos.columns
    seleccion_columna = st.sidebar.selectbox("Selecciona una columna para filtrar", columnas)
    filtro_valor = st.sidebar.text_input(f"Introduce un valor para filtrar la columna {seleccion_columna}")

    if filtro_valor:
        datos_filtrados = datos[datos[seleccion_columna].astype(str).str.contains(filtro_valor, na=False)]
        st.write(f"### Datos filtrados por {seleccion_columna} que contienen '{filtro_valor}'", datos_filtrados.head(10))

# Función para graficar datos
def graficar_datos():
    st.sidebar.header("Visualización de Gráficos")
    datos = st.session_state['datos']  # Recuperar datos de session_state
    tipo_grafico = st.sidebar.selectbox("Selecciona el tipo de gráfico", ["Histograma", "Gráfico de Barras", "Gráfico de Dispersión", "Heatmap", "Boxplot", "Pairplot"])

    columnas = datos.columns

    if tipo_grafico == "Histograma":
        columna_hist = st.sidebar.selectbox("Selecciona una columna para el histograma", columnas)
        if columna_hist:
            st.write(f"### Histograma de {columna_hist}")
            fig, ax = plt.subplots()
            sns.histplot(datos[columna_hist].dropna(), bins=20, kde=True, color='mediumseagreen', ax=ax)
            ax.set_title(f'Distribución de {columna_hist}', fontsize=15)
            ax.set_xlabel(columna_hist, fontsize=12)
            ax.set_ylabel('Frecuencia', fontsize=12)
            plt.xticks(rotation=45)  # Rotar etiquetas de eje X
            st.pyplot(fig)

    elif tipo_grafico == "Gráfico de Barras":
        columna_barras = st.sidebar.selectbox("Selecciona una columna para el gráfico de barras", columnas)
        if columna_barras:
            st.write(f"### Gráfico de Barras de {columna_barras}")
            conteo = datos[columna_barras].value_counts()
            fig, ax = plt.subplots()
            sns.barplot(x=conteo.index, y=conteo.values, palette="pastel", ax=ax)
            ax.set_title(f'Conteo de {columna_barras}', fontsize=15)
            ax.set_xlabel(columna_barras, fontsize=12)
            ax.set_ylabel('Frecuencia', fontsize=12)
            plt.xticks(rotation=45)  # Rotar etiquetas de eje X
            st.pyplot(fig)

    elif tipo_grafico == "Boxplot":
        columna_boxplot = st.sidebar.selectbox("Selecciona una columna para el boxplot", columnas)
        if columna_boxplot:
            st.write(f"### Boxplot de {columna_boxplot}")
            fig, ax = plt.subplots()
            sns.boxplot(x=datos[columna_boxplot], palette="pastel", ax=ax)
            ax.set_title(f'Boxplot de {columna_boxplot}', fontsize=15)
            plt.xticks(rotation=45)  # Rotar etiquetas de eje X si es necesario
            st.pyplot(fig)


# Cargar los datos al iniciar la aplicación
if 'datos' not in st.session_state:
    datos = cargar_datos()

if 'datos' in st.session_state:
    st.sidebar.title("Opciones de Análisis")
    st.sidebar.markdown("Selecciona las opciones de análisis y visualización.")
    explorar_datos()
    graficar_datos()

# Para ejecutar este script, guarda el archivo y utiliza el siguiente comando en tu terminal:
# streamlit run nombre_del_archivo.py